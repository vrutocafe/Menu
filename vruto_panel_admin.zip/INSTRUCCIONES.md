# VRUTO Café — Panel de administración

## Archivos
- `admin.html`: panel privado para iniciar sesión y administrar categorías/productos.
- `supabase_schema.sql`: tablas y reglas de seguridad para Supabase.

## Importante antes de usarlo
El panel administra una base de datos Supabase. Por sí solo no cambia el menú público que ya existe: también hay que conectar el JavaScript de tu `index.html` para que lea `products` y `categories` desde Supabase. Eso es una integración separada para conservar el carrito, tamaños, extras, promoción OFFICE15 y pedido de WhatsApp sin romperlos.

## 1. Crear proyecto
1. Entra a https://supabase.com y crea un proyecto.
2. Guarda la contraseña de base de datos en un lugar seguro.
3. Abre **SQL Editor** → **New query**.
4. Copia y ejecuta el contenido de `supabase_schema.sql`.

## 2. Crear tu usuario
1. En Supabase abre **Authentication → Users → Add user**.
2. Crea tu usuario con tu correo y una contraseña fuerte.
3. Copia el UUID del usuario recién creado.
4. En **SQL Editor**, ejecuta esta consulta sustituyendo el UUID:
   `insert into public.admin_users (user_id) values ('UUID-DEL-USUARIO');`
   No compartas ni publiques el UUID junto con contraseñas; el UUID no sustituye la contraseña.

## 3. Publicar admin.html en GitHub Pages
1. Abre tu repositorio de GitHub donde está la web.
2. Pulsa **Add file → Upload files**.
3. Sube `admin.html` a la misma carpeta donde está el `index.html`.
4. Pulsa **Commit changes**.
5. Si la web usa GitHub Pages desde la rama `main` y carpeta raíz, la dirección será:
   `https://TU-USUARIO.github.io/TU-REPOSITORIO/admin.html`
   Si tienes dominio propio, será `https://TU-DOMINIO/admin.html`.
6. No publiques claves secretas. El panel usa la clave pública (anon/publishable), protegida por las políticas RLS del SQL.

## 4. Abrir el panel
1. Abre `admin.html`.
2. Copia desde Supabase **Project URL** y la clave pública **anon/publishable**.
3. Pulsa Conectar.
4. Inicia sesión con el usuario creado en Supabase.
5. Ya puedes crear categorías, productos, editar precios, ocultar productos o eliminarlos.

## 5. Conectar el menú público (paso necesario)
El panel guarda estos campos:
- `categories`: `id`, `name`, `sort_order`, `active`
- `products`: `id`, `name`, `category_id`, `description`, `product_type`, `cold_price`, `hot_price_12`, `hot_price_16`, `image_url`, `available`, `sort_order`

El `index.html` actual tiene su propio `menuData` en JavaScript. Mientras no se cambie ese código para leer la tabla `products`, las ediciones guardadas aquí NO aparecerán automáticamente en el menú público. Para integrar correctamente hay que adaptar la función que carga/renderiza `menuData` y mapear los campos de Supabase al formato que usa el carrito actual. Hazlo en una copia del `index.html` y prueba antes de reemplazar el archivo publicado.

## Seguridad
- No uses la clave `service_role` en HTML, JavaScript público, GitHub ni capturas.
- No desactives Row Level Security.
- Las reglas permiten lectura pública de productos disponibles y categorías activas; solo los usuarios añadidos a `admin_users` pueden crear, editar o eliminar.
- Si necesitas cambiar qué usuario administra la web, hazlo desde Supabase y actualiza `admin_users`.
