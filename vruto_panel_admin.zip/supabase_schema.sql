-- VRUTO Café: estructura inicial para Supabase
-- Ejecuta todo en Supabase > SQL Editor > New query > Run.
-- IMPORTANTE: nunca publiques ni uses una service_role key en HTML.

create extension if not exists pgcrypto;

create table if not exists public.admin_users (
  user_id uuid primary key references auth.users(id) on delete cascade,
  created_at timestamptz not null default now()
);

create table if not exists public.categories (
  id uuid primary key default gen_random_uuid(),
  name text not null unique,
  sort_order integer not null default 0,
  active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.products (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  category_id uuid references public.categories(id) on delete restrict,
  description text,
  product_type text not null default 'cold'
    check (product_type in ('cold','hot','both','food')),
  cold_price numeric(10,2) check (cold_price is null or cold_price >= 0),
  hot_price_12 numeric(10,2) check (hot_price_12 is null or hot_price_12 >= 0),
  hot_price_16 numeric(10,2) check (hot_price_16 is null or hot_price_16 >= 0),
  image_url text,
  available boolean not null default true,
  sort_order integer not null default 0,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists products_category_id_idx on public.products(category_id);
create index if not exists products_available_idx on public.products(available);
create index if not exists products_sort_order_idx on public.products(sort_order);

alter table public.admin_users enable row level security;
alter table public.categories enable row level security;
alter table public.products enable row level security;

-- Reglas: cualquiera puede leer solo categorías activas y productos disponibles.
drop policy if exists "Public can read active categories" on public.categories;
create policy "Public can read active categories" on public.categories
for select to anon, authenticated using (active = true);

drop policy if exists "Public can read available products" on public.products;
create policy "Public can read available products" on public.products
for select to anon, authenticated using (available = true);

-- Los administradores se autorizan mediante admin_users.
drop policy if exists "Admins can read all categories" on public.categories;
create policy "Admins can read all categories" on public.categories
for select to authenticated using (
  exists (select 1 from public.admin_users a where a.user_id = auth.uid())
);
drop policy if exists "Admins can insert categories" on public.categories;
create policy "Admins can insert categories" on public.categories
for insert to authenticated with check (
  exists (select 1 from public.admin_users a where a.user_id = auth.uid())
);
drop policy if exists "Admins can update categories" on public.categories;
create policy "Admins can update categories" on public.categories
for update to authenticated using (
  exists (select 1 from public.admin_users a where a.user_id = auth.uid())
) with check (
  exists (select 1 from public.admin_users a where a.user_id = auth.uid())
);
drop policy if exists "Admins can delete categories" on public.categories;
create policy "Admins can delete categories" on public.categories
for delete to authenticated using (
  exists (select 1 from public.admin_users a where a.user_id = auth.uid())
);

drop policy if exists "Admins can read all products" on public.products;
create policy "Admins can read all products" on public.products
for select to authenticated using (
  exists (select 1 from public.admin_users a where a.user_id = auth.uid())
);
drop policy if exists "Admins can insert products" on public.products;
create policy "Admins can insert products" on public.products
for insert to authenticated with check (
  exists (select 1 from public.admin_users a where a.user_id = auth.uid())
);
drop policy if exists "Admins can update products" on public.products;
create policy "Admins can update products" on public.products
for update to authenticated using (
  exists (select 1 from public.admin_users a where a.user_id = auth.uid())
) with check (
  exists (select 1 from public.admin_users a where a.user_id = auth.uid())
);
drop policy if exists "Admins can delete products" on public.products;
create policy "Admins can delete products" on public.products
for delete to authenticated using (
  exists (select 1 from public.admin_users a where a.user_id = auth.uid())
);

-- Después de crear tu usuario en Authentication, agrega su UUID aquí:
-- insert into public.admin_users (user_id) values ('PEGA-AQUI-EL-UUID-DEL-USUARIO');

-- Categorías iniciales de ejemplo. Puedes editarlas desde el panel.
insert into public.categories (name, sort_order)
values
 ('Cafés calientes', 10),
 ('Cafés fríos', 20),
 ('Matcha y especiales', 30),
 ('Panadería y alimentos', 40)
on conflict (name) do nothing;
